import React from 'react';

export default function Product(props) {
  return (
    <div className="item-box" id={props.alt}>
      <img src={props.src} alt={props.alt} />
      <p className="caption">{props.alt}</p>
      <p className="subheading">{'$' + parseInt(props.price)}</p>
    </div>
  );
}
