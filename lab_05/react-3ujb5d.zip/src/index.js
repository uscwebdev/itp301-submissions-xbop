import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Imani Musembi</h1>
    <p id="email">
      <a href="mailto:musembi@usc.edu" target="_blank">
        musembi@usc.edu
      </a>
    </p>
    <hr />
    <p id="favorite-color">Favorite Color: Purple</p>
    <p>
      Favorite Website:
      <a href="roblox.com" target="_blank">
        Roblox
      </a>
    </p>
    <img
      src="https://www.clistudios.com/wp-content/uploads/2021/08/jaquel-knight-hip-hop-1024x683.jpeg"
      alt="Hip Hop Dance"
    />
    <p>Fall 2023 Courses</p>
    <ul>
      <li className="course-name">Introduction to Neurobiology</li>
      <li>BISC 421</li>
      <li className="course-name">Hip Hop Dance</li>
      <li>DANC 185B</li>
      <li className="course-name">Origins of Jazz Dance</li>
      <li>DANC 333</li>
      <li className="course-name">Front End Development</li>
      <li>ITP 301</li>
      <li className="course-name">Introduction to User Experience</li>
      <li>ITP 310</li>
    </ul>
  </React.StrictMode>
);
