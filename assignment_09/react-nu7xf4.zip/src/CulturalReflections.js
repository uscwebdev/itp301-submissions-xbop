import React from 'react';
import './index.css';

export default function CulturalReflections() {
  return (
    <section className="content cultural-reflections">
      <div className="interactive-elements">
        <h2>Cultural Reflections</h2>
        <form>
          <p>Do you believe jazz has faced cultural appropriation?</p>
          <div className="align-middle form-check form-check-inline">
            <input
              className="form-check-input"
              type="radio"
              id="yes"
              name="appropriation"
              value="yes"
            />
            <label className="form-check-label my-1" htmlFor="yes">
              Yes
            </label>
          </div>
          <div className="align-middle form-check form-check-inline">
            <input
              className="form-check-input"
              type="radio"
              id="yes"
              name="appropriation"
              value="no"
            />
            <label className="form-check-label my-1" htmlFor="no">
              No
            </label>
          </div>
          <br />
          {/* More options can be added */}
          <button type="submit">Submit</button>
        </form>
      </div>
      <div className="discussion">
        <h2>Discussion</h2>
        <div id="appropriation-img-container">
          <img
            id="appropriation-img"
            src="https://i0.wp.com/www.michigandaily.com/wp-content/uploads/2020/10/BlackMusic_Kai.jpg?fit=720%2C576&ssl=1"
            alt="Cultural Appropriation in Jazz"
          />
        </div>
        <p>
          Cultural appropriation in jazz has been a topic of debate for decades.
          It involves the adoption of certain elements of jazz by mainstream
          culture without acknowledgment or respect for its origins. This often
          leads to erasure or misrepresentation of the cultural significance and
          contributions of the African American community to jazz. Images and
          stories related to instances of cultural appropriation can be explored
          here.
        </p>
        {/* Additional content regarding cultural appropriation */}
      </div>
      <div className="user-comments">
        <h2>User Comments</h2>
        <textarea
          placeholder="Share your thoughts..."
          rows="4"
          cols="50"
        ></textarea>
        <br />
        <button type="submit">Post Comment</button>
        {/* Display existing user comments */}
        {/* <div className="comment">
          <p>User comment regarding cultural appropriation...</p>
        </div> */}
        {/* More user comments or a scrollable area */}
      </div>
    </section>
  );
}
