import React from 'react';
import './index.css';

export default function JazzThroughTheAges() {
  return (
    <section className="content jazz-through-the-ages">
      <div className="introduction">
        <h2>Jazz Through the Ages</h2>
        <p id="paragraph">
          With its origins in the African American community, jazz became a
          voice of resilience and freedom, echoing the experiences and struggles
          of its creators. From the raw, improvised tunes in the smoky clubs of
          New Orleans to the swing era that swept the nation in the 1930s and
          the bebop innovations of the 1940s, jazz has constantly evolved,
          embracing diverse influences and pushing artistic boundaries.
        </p>
      </div>
      <div className="timeline">
        <h2>Interactive Timeline</h2>
        <div className="timeline-container">
          <div className="timeline-item">
            <div className="timeline-year">1920s</div>
            <div className="timeline-event">Birth of Jazz</div>
            <div class="information-box">
              <img
                id="info-img"
                src="https://upload.wikimedia.org/wikipedia/commons/2/26/CarterAndKingJazzingOrchestra.jpg"
                alt="Birth of Jazz"
              />
              <div class="info-details">
                <h3>Birth of Jazz</h3>
                <p>
                  Jazz is a music genre that originated in the Black-American
                  communities of New Orleans, Louisiana, in the late 19th and
                  early 20th centuries, and developed from roots in blues and
                  ragtime. New Orleans provided a cultural humus in which jazz
                  could germinate because it was a port city with many cultures
                  and beliefs intertwined. In New Orleans, the development of
                  jazz was influenced by Creole music, ragtime, and blues.
                </p>
              </div>
            </div>
          </div>
          <div className="timeline-item">
            <div className="timeline-year">1930s</div>
            <div className="timeline-event">Swing Era</div>
          </div>
          <div className="timeline-item">
            <div className="timeline-year">1940s</div>
            <div className="timeline-event">Bebop Emerges</div>
          </div>
          {/* More timeline items */}
        </div>
      </div>
      {/* <div className="multimedia-elements">
        <h2>Multimedia Elements</h2> */}
      {/* Videos, audio clips, images */}
      {/* </div> */}
    </section>
  );
}
