import React from 'react';
import { useState } from 'react';

export default function Product() {
  const [subtotal, setSubtotal] = useState(0);

  function handleCountAdd(price) {
    console.log('handleCountUpdate invoked');
    setSubtotal(subtotal + price);
  }

  function handleCountSub(price) {
    console.log('handleCountUpdate invoked');
    setSubtotal(subtotal - price);
  }

  return (
    <div id="color-boxes" className="container mt-3">
      <div className="items">
        <Products
          alt="Pepperoni Pizza"
          src="https://media.istockphoto.com/id/888018918/photo/pepperoni-pizza-isolated-on-white-background.jpg?s=612x612&w=0&k=20&c=rQLuRGwPzXtSBiG7FqS6iDeXP4UaMzkNgYiCHrqItiY="
          price="15"
          parentEventHandler={() => handleCountSub(15)}
          parentEventHandlerTwo={() => handleCountAdd(15)}
        />
        <Products
          alt="Breadsticks"
          src="https://media.istockphoto.com/id/1075293248/photo/bread-sticks-on-white-background.jpg?s=170667a&w=0&k=20&c=eNzfZ91ibVnJ5FfRA1wGb2d62UCRAH_D3W3f4PJhiAg="
          price="5"
          parentEventHandler={() => handleCountSub(5)}
          parentEventHandlerTwo={() => handleCountAdd(5)}
        />
        <Products
          alt="Marinara Sauce"
          src="https://media.istockphoto.com/id/1054579050/photo/container-of-marinara-tomato-sauce-isolated-on-white.jpg?s=612x612&w=0&k=20&c=A7ACd-eQuPxWhJTXh0bzDFSFZjd0bM4BVU8Lmhu3gXs="
          price="2"
          parentEventHandler={() => handleCountSub(2)}
          parentEventHandlerTwo={() => handleCountAdd(2)}
        />
        <Products
          alt="Ranch"
          src="https://media.istockphoto.com/id/969655840/photo/ranch-dressing-in-cup-isolated-on-white.jpg?s=612x612&w=0&k=20&c=GJRmw7KIDmtBOJhM2848lTs6HS4Rbjz5EzqK3U1XkwE="
          price="2"
          parentEventHandler={() => handleCountSub(2)}
          parentEventHandlerTwo={() => handleCountAdd(2)}
        />
      </div>

      <div className="row">
        <p className="col-12 mt-4">Subtotal: ${subtotal}</p>
      </div>
    </div>
  );
}

function Products(props) {
  const [count, setCount] = useState(0);

  function handlePlusClick() {
    console.log('Button clicked');
    console.log(count);
    setCount(count + 1);
    console.log(count);
  }

  function handleMinusClick() {
    console.log('Button clicked');
    console.log(count);
    if (count > 0) {
      props.parentEventHandler();
      setCount(count - 1);
    }
    console.log(count);
  }

  return (
    <div className="item-box" id={props.alt}>
      <img src={props.src} alt={props.alt} />
      <p className="caption">{props.alt}</p>
      <p className="subheading">{'$' + parseInt(props.price)}</p>
      <div className="btn-group">
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 mt-2 col col-sm-4 col-md-3"
          onClick={() => {
            handleMinusClick();
            // props.parentEventHandler();
          }}
        >
          -
        </button>
        <p className="mt-3">{count}</p>
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 mt-2 col col-sm-4 col-md-3"
          onClick={() => {
            handlePlusClick();
            props.parentEventHandlerTwo();
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}
