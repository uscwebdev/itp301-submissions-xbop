import React from 'react';
import { createRoot } from 'react-dom/client';
import Product from './Product.js';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h1>My Cart</h1>
    </div>
    <div className="items">
      <Product
        alt="Pepperoni Pizza"
        src="https://media.istockphoto.com/id/888018918/photo/pepperoni-pizza-isolated-on-white-background.jpg?s=612x612&w=0&k=20&c=rQLuRGwPzXtSBiG7FqS6iDeXP4UaMzkNgYiCHrqItiY="
        price="15"
      />
      <Product
        alt="Breadsticks"
        src="https://media.istockphoto.com/id/1075293248/photo/bread-sticks-on-white-background.jpg?s=170667a&w=0&k=20&c=eNzfZ91ibVnJ5FfRA1wGb2d62UCRAH_D3W3f4PJhiAg="
        price="5"
      />
      <Product
        alt="Marinara Sauce"
        src="https://media.istockphoto.com/id/1054579050/photo/container-of-marinara-tomato-sauce-isolated-on-white.jpg?s=612x612&w=0&k=20&c=A7ACd-eQuPxWhJTXh0bzDFSFZjd0bM4BVU8Lmhu3gXs="
        price="2"
      />
      <Product
        alt="Ranch"
        src="https://media.istockphoto.com/id/969655840/photo/ranch-dressing-in-cup-isolated-on-white.jpg?s=612x612&w=0&k=20&c=GJRmw7KIDmtBOJhM2848lTs6HS4Rbjz5EzqK3U1XkwE="
        price="2"
      />
    </div>
  </React.StrictMode>
);
