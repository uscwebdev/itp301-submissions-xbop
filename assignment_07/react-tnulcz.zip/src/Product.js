import React from 'react';
import { useState } from 'react';

export default function Product(props) {
  const [count, setCount] = useState(0);

  function handlePlusClick() {
    console.log('Button clicked');
    console.log(count);
    setCount(count + 1);
    console.log(count);
  }

  function handleMinusClick() {
    console.log('Button clicked');
    console.log(count);
    if (count > 0) {
      setCount(count - 1);
    }
    console.log(count);
  }

  return (
    <div className="item-box" id={props.alt}>
      <img src={props.src} alt={props.alt} />
      <p className="caption">{props.alt}</p>
      <p className="subheading">{'$' + parseInt(props.price)}</p>
      <div className="btn-group">
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 mt-2 col col-sm-4 col-md-3"
          onClick={handleMinusClick}
        >
          -
        </button>
        <p className="mt-3">{count}</p>
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 mt-2 col col-sm-4 col-md-3"
          onClick={handlePlusClick}
        >
          +
        </button>
      </div>
    </div>
  );
}
