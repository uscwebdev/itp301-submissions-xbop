import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Amazon Mascara Faves</h1>
    <div className="thumbnail">
      <img
        className="product"
        src="https://m.media-amazon.com/images/I/61K6cQhw4EL._SL1500_.jpg"
        alt="Lash Princess"
      />
      <a
        href="https://www.amazon.com/essence-Princess-Effect-Mascara-Cruelty/dp/B00T0C9XRK/ref=sr_1_1_sspa?crid=EOJEV8PME4YH&keywords=mascara&qid=1695708444&sprefix=mas%2Caps%2C200&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1"
        target="_blank"
      >
        <h4>Lash Princess</h4>
      </a>
      <hr />
      <img
        className="pfp"
        src="https://media.glamour.com/photos/56966e6793ef4b095210f051/master/w_1600%2Cc_limit/beauty-2014-04-lupita-nyongo-people-most-beautiful-woman-main.jpg"
        alt="Lupita"
      />
      <p>LupitaRUs - 4 stars</p>
      <p>September 19, 2023</p>
      <p>
        "I was kind of blown away the first time I tried this mascara because it
        really does give a false lash effect! I already have nice lashes and
        this stuff really makes em POP. I think next time I'll be getting the
        waterproof version though as this stuff tends to start transferring by
        the end of the day."
      </p>
    </div>
    <div className="thumbnail">
      <img
        className="product"
        src="https://m.media-amazon.com/images/I/716QR-UMW3L._SL1500_.jpg"
        alt="L’Oreal Paris"
      />
      <a
        href="https://www.amazon.com/LOreal-Paris-Voluminous-Original-Building/dp/B000R1VH8Q/ref=sr_1_5_pp?crid=EOJEV8PME4YH&keywords=mascara&qid=1695708444&sprefix=mas%2Caps%2C200&sr=8-5"
        target="_blank"
      >
        <h4>L’Oreal Paris</h4>
      </a>
      <hr />
      <img
        className="pfp"
        src="https://media.vogue.co.uk/photos/64fed45cc5bc8fbcaf973bfa/2:3/w_2560%2Cc_limit/news1109_GettyImages-1500117177.jpg"
        alt="Zendaya"
      />
      <p>SpiderGF - 5 stars</p>
      <p>September 19, 2023</p>
      <p>
        "This is by far the best mascara made .. I admit I tried others along
        the way BUT always came back to Voluminous its the only one that really
        gives you big long eyelashes.. I learned from my mistakes trying others
        they can’t compare or compete with it.. Try it you won’t be
        disappointed..😊"
      </p>
    </div>
    <div className="thumbnail">
      <img
        className="product"
        src="https://m.media-amazon.com/images/I/61lbaTavonL._SL1500_.jpg"
        alt="L’Oreal Paris Lash Paradise"
      />
      <a
        href="https://www.amazon.com/LOreal-Paris-Voluminous-Paradise-Washable/dp/B06XF2TR11/ref=sr_1_7?crid=EOJEV8PME4YH&keywords=mascara&qid=1695708444&sprefix=mas%2Caps%2C200&sr=8-7"
        target="_blank"
      >
        <h4>L’Oreal Paris Lash Paradise</h4>
      </a>
      <hr />
      <img
        className="pfp"
        src="https://www.brides.com/thmb/-67UPSK4zbkg0N-GI3MNvLPylpo=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/__opt__aboutcom__coeus__resources__content_migration__brides__proteus__5c9a3d09b9f6af56fb6fbf40__11-2d270a65f6474ab9b3d771a8a3868f46.jpeg"
        alt="Issa Rae"
      />
      <p>PresidentBarbie - 5 stars</p>
      <p>September 23, 2023</p>
      <p>
        "I have been using Lorel mascara for years. The one I used to use was
        discontinued. I tried other brands and came back to this one. It works
        really well and gets all of my lashes. It also lasts for hours. My only
        complaint would be that I feel like it doesn't last long and I have to
        buy it once a month. I wear it pretty much every day but I only apply it
        once and I feel like it runs out. Maybe they're putting less in the
        tube. But I still love it."
      </p>
    </div>
    <div className="thumbnail">
      <img
        className="product"
        src="https://m.media-amazon.com/images/I/71mijtOezSL._SL1500_.jpg"
        alt="Maybelline New York"
      />
      <a
        href="https://www.amazon.com/Maybelline-New-York-Washable-Volumizing/dp/B09J5HRNTM/ref=sr_1_8?crid=EOJEV8PME4YH&keywords=mascara&qid=1695708444&rdc=1&sprefix=mas%2Caps%2C200&sr=8-8"
        target="_blank"
      >
        <h4>Maybelline New York</h4>
      </a>
      <hr />
      <img
        className="pfp"
        src="https://globalgrind.com/wp-content/uploads/sites/16/2021/11/1636593272993.jpg?strip=all&quality=80"
        alt="Halle Bailey"
      />
      <p>Dinglehopper - 5 stars</p>
      <p>September 19, 2023</p>
      <p>
        "Out of all the mascaras I have, this one is always a go-to for me! Easy
        to apply, the wand is perfect if you don’t want a lot on, but you can
        also add layers giving SO much volume to your lashes. The mascara itself
        is not heavy so your lashes are able to stay curled after you apply your
        mascara which is perfect for me since without a curler they stick
        straight out. Overall, one of the best mascaras I’ve used. Only take
        back is that if you apply it on bottom lashes, it will smear onto the
        bottom eyelid. This is how it’s been for me for all mascaras I’ve used
        though."
      </p>
    </div>
  </React.StrictMode>
);
