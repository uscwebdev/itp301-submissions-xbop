import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [passwordTwo, setPasswordTwo] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comments, setComments] = useState('');
  const [terms, setTerms] = useState(false);
  // const [count, setCount] = useState(0);

  const [usernameError, setUsernameError] = useState();
  const [passwordError, setPasswordError] = useState();
  const [passwordTwoError, setPasswordTwoError] = useState();
  const [emailError, setEmailError] = useState();
  const [phoneError, setPhoneError] = useState();
  const [commentsError, setCommentsError] = useState();
  const [termsError, setTermsError] = useState();

  function handleSubmit(e) {
    // e.preventDefault();
    // console.log('form submitted');

    var foundError = false;

    /*
      Username cannot be empty.
      Username cannot contain uppercase letters.
    */
    if (username.length == 0) {
      // Username is empty.
      foundError = true;
      setUsernameError('Name cannot be empty.');
    } else if (username.indexOf(' ') == -1) {
      // Username doesn't have space.
      foundError = true;
      setUsernameError('You must provide a full name.');
    } else {
      // No errors.
      setUsernameError('');
    }

    if (password.length == 0) {
      // Username is empty.
      foundError = true;
      setPasswordError('Password cannot be empty.');
    } else if (password.length < 5) {
      foundError = true;
      setPasswordError('Password must contain at least 5 characters.');
    } else if (password == password.toLowerCase()) {
      // Username contains uppercase characters.
      foundError = true;
      setPasswordError(
        'Password must contain uppercase and lowercase characters.'
      );
    } else if (password == password.toUpperCase()) {
      // Username contains uppercase characters.
      foundError = true;
      setPasswordError(
        'Password must contain uppercase and lowercase characters.'
      );
    } else {
      // No errors.
      setPasswordError('');
    }

    if (password != passwordTwo) {
      foundError = true;
      setPasswordTwoError('Passwords do not match.');
    }

    if (email.length == 0 && phone.length == 0) {
      foundError = true;
      setEmailError('You must provide either email or phone.');
      setPhoneError('You must provide either email or phone.');
    } else {
      setEmailError('');
      setPhoneError('');
    }

    if (comments.length > 100) {
      foundError = true;
      setCommentsError('Comments cannot exceed 100 characters.');
    } else {
      setCommentsError('');
    }

    if (terms == false) {
      foundError = true;
      setTermsError('You must accept Terms & Conditions.');
    } else {
      setTermsError('');
    }

    if (foundError == true) {
      // Have form validation errors.
      // Prevent it from submitting.
      e.preventDefault();
    } else {
      // No errors.
      // Display the confirmation.
      // Let the form submit.
      alert('Registration Successful');
    }
  }

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setUsername(e.currentTarget.value);
                  }}
                  value={username}
                />

                <small id="username-error" className="form-text text-danger">
                  {usernameError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setPassword(e.currentTarget.value);
                  }}
                  value={password}
                  type="password"
                  className="form-control"
                  id="password"
                />

                <small id="password-error" className="form-text text-danger">
                  {passwordError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setPasswordTwo(e.currentTarget.value);
                  }}
                  value={passwordTwo}
                  type="password"
                  className="form-control"
                  id="password-confirm"
                />

                <small
                  id="password-two-error"
                  className="form-text text-danger"
                >
                  {passwordTwoError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      onChange={(e) => {
                        setEmail(e.currentTarget.value);
                      }}
                      value={email}
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                    />

                    <small id="email-error" className="form-text text-danger">
                      {emailError}
                    </small>
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      onChange={(e) => {
                        setPhone(e.currentTarget.value);
                      }}
                      value={phone}
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                    />

                    <small id="phone-error" className="form-text text-danger">
                      {phoneError}
                    </small>
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  onChange={(e) => {
                    setComments(e.currentTarget.value);
                  }}
                  value={comments}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {comments.length} / 100
                </small>
              </div>

              <small id="comments-error" className="form-text text-danger">
                {commentsError}
              </small>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    onChange={() => {
                      setTerms(!terms);
                    }}
                    checked={terms}
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>

                <small id="terms-error" className="form-text text-danger">
                  {termsError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
