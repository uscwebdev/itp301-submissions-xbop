import React from 'react';

export default function ChangingImg(props) {
  return (
    <div id="heart-section" className="container mt-4">
      <div className="row">
        <h2 className="col-12">Heartstopper Cuties</h2>
      </div>
      <img id="couple" src={props.src} alt={props.alt} />
      {/* <br /> */}
      <h5>
        <p className="text-center">{props.alt}</p>
      </h5>
    </div>
  );
}
