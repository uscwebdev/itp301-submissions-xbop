import React from 'react';
import ChangingImg from './ChangingImg.js';
import { useState } from 'react';

export default function Buttons() {
  const [index, setIndex] = useState(0);

  var imgArray = [
    'https://static.independent.co.uk/2023/08/02/15/newFile-2.jpg?width=1200&height=1200&fit=crop',
    'https://i.pinimg.com/736x/a7/9f/83/a79f835e7a83703c49f0e7b0a9ad621b.jpg',
    'https://www.refinery29.com/images/10956749.jpg',
    'https://i.redd.it/gla3mkaw0f3a1.jpg',
    'https://hips.hearstapps.com/hmg-prod/images/screen-shot-2023-08-07-at-4-47-17-pm-64d1586290919.png',
  ];
  var altArray = [
    'Nick and Charlie',
    'Tao and Elle',
    'Tara and Darcy',
    'Mr. Farouk and Mr. Ajayi',
    'Isaac',
  ];

  function handleClick(count) {
    setIndex(count);
  }

  return (
    <div id="button-section" className="container mt-4">
      <div className="row">
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 col col-sm-4 col-md-3"
          onClick={() => handleClick(0)}
        >
          Image 1
        </button>
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 col col-sm-4 col-md-3"
          onClick={() => handleClick(1)}
        >
          Image 2
        </button>
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 col col-sm-4 col-md-3"
          onClick={() => handleClick(2)}
        >
          Image 3
        </button>
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 col col-sm-4 col-md-3"
          onClick={() => handleClick(3)}
        >
          Image 4
        </button>
        <button
          className="btn-click"
          className="btn btn-secondary mx-2 col col-sm-4 col-md-3"
          onClick={() => handleClick(4)}
        >
          Image 5
        </button>
      </div>
      <ChangingImg src={imgArray[index]} alt={altArray[index]} />
    </div>
  );
}
