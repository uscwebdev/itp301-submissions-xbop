import React from 'react';

export default function UserReview(props) {
  return (
    <div className="thumbnail">
      <img src={props.src} alt={props.caption} className="product" />
      <a href={props.product} target="_blank">
        <h4>{props.caption}</h4>
      </a>
      <hr />
      <img className="pfp" src={props.src2} alt={props.caption2} />
      <p>{props.username}</p>
      <p>{props.date}</p>
      <p>{props.review}</p>
    </div>
  );
}
